import requests

class Status:
    def stellular():
        json = {"JSON": "LOl"}
        return json
