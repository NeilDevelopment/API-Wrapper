import requests

def stellular():
    # resp = requests.get("https://api.neildevelopment.xyz/status/stellular")
    # json = resp.json()
    # return json
    print("Stellular status")